# MetalOS v3 — 64-bit build package

This is a Debian 13 (Trixie) live-build project for **amd64 (64-bit Intel/AMD PCs)**.

## Included design
- KDE Plasma desktop with a dark, glass-inspired MetalOS layout
- Windows 2000-inspired classic Start menu cues combined with modern rounded panels
- First-launch setup wizard (language, username, theme and network reminder)
- MetalTerminal launcher
- Metal Apps starter app centre
- OBS Studio from Debian packages
- Discord installed through Flatpak/Flathub after the first boot (Discord is not in Debian's standard repositories)

## Build the ISO
Use a Debian 13 amd64 machine with internet access, at least 20 GB free disk space, and sudo/root access.

```bash
sudo apt update
sudo apt install -y live-build
cd MetalOS-v3-64bit
sudo lb config
sudo lb build
```

The resulting ISO is normally named `live-image-amd64.hybrid.iso`.

## Important
- This package is **build source**, not a prebuilt ISO.
- It targets **64-bit only**. It does not include 32-bit support.
- Discord is set up via Flatpak during the first-run provisioning step; internet access is required.
- Kernel version is selected by Debian 13's kernel package (`linux-image-amd64`); the exact installed kernel can vary with repository updates. It is not hard-pinned to 6.12.
- Review scripts before running them. This project does not bypass Secure Boot or change firmware settings.
